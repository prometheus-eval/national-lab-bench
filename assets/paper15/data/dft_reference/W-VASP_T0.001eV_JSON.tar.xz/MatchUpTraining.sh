lines=`wc -l TrainingEnergies.dat | awk '{print($1)}'`
for i in $(seq 1 1 ${lines})
do
head -n$i TrainingEnergies.dat | tail -n1 > string

folder=`cat string | awk '{print($1)}'`
file=`cat string | awk '{print($2)}'`
nats1=`cat string | awk '{print($3)}'`
feng1=`cat string | awk '{print($5)}'`
eng1=`cat string | awk '{print($7)}'`

nats2=`grep "NumAtoms" /nscratch/mitwood/EC_FES_NonEqMech/ModelDevelopment/SommerfeldPotentials/W/TrainingDataVASP_T0.01/CompletedTrainingSet/${folder}`
feng2=`grep "FreeEng"  /nscratch/mitwood/EC_FES_NonEqMech/ModelDevelopment/SommerfeldPotentials/W/TrainingDataVASP_T0.01/CompletedTrainingSet/${folder}`
eng2=`grep "Energy\"" /nscratch/mitwood/EC_FES_NonEqMech/ModelDevelopment/SommerfeldPotentials/W/TrainingDataVASP_T0.01/CompletedTrainingSet/${folder}`

echo ${folder} ${nats1} ${feng1} ${eng1} ${nats2} ${feng2} ${eng2} >> MatchedTrainingEnergies_0.001_0.01.dat
done

awk '{if(NF==10)print($0,((($3-$8)**2.0)**0.5)/$2,((($4-$10)**2.0)**0.5)/$2)}' MatchedTrainingEnergiesDiff_0.001_0.01.dat 
