
function flip () {
        input=$1
        awk '{for (i=1; i<=NF; i++) a[i]=a[i](NR!=1?FS:"")$i} END {for (i=1; i in a; i++) print(a[i])}' $input
}


for folder in BCC_ForceLib_W110 BCC_ForceLib_WOct Divacancy surface BCC_ForceLib_W111 BCC_ForceLib_WTet Disordered_Struc EOS_Data slice_sample gamma_surface gamma_surface_vacancy dislocation_quadrupole md_bulk vacancy ObjectiveFunctions NotConverged
do
list=`ls -ltrh ${folder}/*.json | awk '{print($9)}' |  flip`
for i in ${list}
do
nats=`grep "NumAtoms" ${i}`
feng=`grep "FreeEng"  ${i}`
ener=`grep "Energy\"" ${i}`

echo ${i} ${nats} ${feng} ${ener} >> TrainingEnergies.dat
done
done
