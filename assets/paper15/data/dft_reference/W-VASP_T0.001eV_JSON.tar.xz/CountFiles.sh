#This will collect all JSON and OUTCARS files

for folder in BCC_ForceLib_W110 BCC_ForceLib_WOct Divacancy surface BCC_ForceLib_W111 BCC_ForceLib_WTet Disordered_Struc EOS_Data slice_sample
do
cd ${folder}
count=`ls -ltrh *.json | wc -l`
#tar -cf ${folder}_OUTCARS.tar VASPData/*
#tar -cf ${folder}_JSON.tar JSONFiles/*
echo ${folder} ${count}
cd ../
done

for folder in dislocation_quadrupole md_bulk vacancy
do
cd ${folder}
#tar -cf ${folder}_OUTCARS.tar Run_*/VASPData/*
#tar -cf ${folder}_JSON.tar Run_*/*.json
count=`ls -ltrh *.json | wc -l`
echo ${folder} ${count}
cd ../
done

for folder in gamma_surface gamma_surface_vacancy NotConverged
do
cd ${folder}
#tar -cf ${folder}_OUTCARS.tar work/run-.*/VASPData/*OUTCAR
#tar -cf ${folder}_JSON.tar work/run-.*/*.json
count=`ls -ltrh *.json | wc -l`
echo ${folder} ${count}
cd ../
done
